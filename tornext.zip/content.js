// Retrieve the saved image URL and darkness level from chrome.storage and apply them
chrome.storage.sync.get(["tornBackgroundImage", "backgroundDarkness"], (data) => {
    if (data.tornBackgroundImage) {
        const darknessValue = data.backgroundDarkness || 50; // Default to 50% if not set
        changeBackground(data.tornBackgroundImage, darknessValue);
    }
});

function changeBackground(imageUrl, darknessValue) {
    const element = document.querySelector("#body > div.content.responsive-sidebar-container.logged-in");
    if (element) {
        const opacity = darknessValue / 100;
        element.style.backgroundImage = `url('${imageUrl}')`;
        element.style.backgroundSize = "contain"; // Make sure the image covers the element
        element.style.backgroundRepeat = "x-repeat"; // Prevent the image from repeating
        element.style.backgroundPosition = "center"; // Center the image
        element.style.position = "relative"; // Ensure the element is positioned relative for the overlay

        // Create a customizable dark overlay effect
        element.style.backgroundColor = `rgba(0, 0, 0, ${opacity})`; // Darken the background with the selected opacity
        element.style.backgroundBlendMode = "overlay"; // Blend the image with the overlay color
    }
}

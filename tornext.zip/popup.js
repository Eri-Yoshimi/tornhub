document.addEventListener('DOMContentLoaded', () => {
    // Retrieve the saved background type, image URL, darkness level, and color from chrome.storage
    chrome.storage.sync.get(["backgroundType", "tornBackgroundImage", "backgroundDarkness", "backgroundColor"], (data) => {
        const backgroundType = data.backgroundType || 'image';
        document.getElementById('backgroundType').value = backgroundType;

        if (backgroundType === 'image') {
            document.getElementById('imageOptions').style.display = 'block';
            document.getElementById('colorOptions').style.display = 'none';

            if (data.tornBackgroundImage) {
                document.getElementById('imageUrl').value = data.tornBackgroundImage;
            }
            if (data.backgroundDarkness) {
                const darknessValue = data.backgroundDarkness;
                document.getElementById('darknessRange').value = darknessValue;
                document.getElementById('darknessValue').textContent = `${darknessValue}%`;
            }
        } else {
            document.getElementById('imageOptions').style.display = 'none';
            document.getElementById('colorOptions').style.display = 'block';

            if (data.backgroundColor) {
                document.getElementById('backgroundColor').value = data.backgroundColor;
            }
        }
    });

    document.getElementById('backgroundType').addEventListener('change', () => {
        const backgroundType = document.getElementById('backgroundType').value;
        if (backgroundType === 'image') {
            document.getElementById('imageOptions').style.display = 'block';
            document.getElementById('colorOptions').style.display = 'none';
        } else {
            document.getElementById('imageOptions').style.display = 'none';
            document.getElementById('colorOptions').style.display = 'block';
        }
    });

    document.getElementById('darknessRange').addEventListener('input', () => {
        const darknessValue = document.getElementById('darknessRange').value;
        document.getElementById('darknessValue').textContent = `${darknessValue}%`;
    });

    document.getElementById('changeBackground').addEventListener('click', () => {
        const backgroundType = document.getElementById('backgroundType').value;
        const imageUrl = document.getElementById('imageUrl').value;
        const darknessValue = document.getElementById('darknessRange').value;
        const backgroundColor = document.getElementById('backgroundColor').value;

        chrome.storage.sync.set({ 
            backgroundType: backgroundType,
            tornBackgroundImage: backgroundType === 'image' ? imageUrl : '',
            backgroundDarkness: backgroundType === 'image' ? darknessValue : '',
            backgroundColor: backgroundType === 'color' ? backgroundColor : ''
        }, () => {
            console.log("Background settings saved.");
        });

        // Apply the background immediately
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            chrome.scripting.executeScript({
                target: { tabId: tabs[0].id },
                function: changeBackground,
                args: [backgroundType, imageUrl, darknessValue, backgroundColor]
            });
        });
    });
});

// Function to change the background based on type, image URL, darkness level, and color
function changeBackground(backgroundType, imageUrl, darknessValue, backgroundColor) {
    const element = document.querySelector("#body > div.content.responsive-sidebar-container.logged-in");
    if (element) {
        if (backgroundType === 'image') {
            const opacity = darknessValue / 100;
            element.style.backgroundImage = `url('${imageUrl}')`;
            element.style.backgroundSize = "contain"; // Make sure the image covers the element
            element.style.backgroundRepeat = "x-repeat"; // Prevent the image from repeating
            element.style.backgroundPosition = "center"; // Center the image
            element.style.position = "relative"; // Ensure the element is positioned relative for the overlay

            // Create a customizable dark overlay effect
            element.style.backgroundColor = `rgba(0, 0, 0, ${opacity})`; // Darken the background with the selected opacity
            element.style.backgroundBlendMode = "overlay"; // Blend the image with the overlay color
        } else if (backgroundType === 'color') {
            element.style.backgroundImage = 'none'; // Remove the image
            element.style.backgroundColor = backgroundColor; // Apply the solid color
        }
    }
}
